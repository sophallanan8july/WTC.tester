// This is a placeholder. In a real app, you'd check roles via tokens.
module.exports = function (req, res, next) {
  const isAdmin = true; // Replace with actual admin check
  if (!isAdmin) {
    return res.status(403).json({ error: "Access denied" });
  }
  next();
};
